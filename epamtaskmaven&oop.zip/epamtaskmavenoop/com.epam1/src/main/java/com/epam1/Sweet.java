package com.epam1;

public class Sweet extends Gift{

	public Sweet(int weight, int sweetness, String color) {
		super(weight, sweetness, color);
	}
	
}
